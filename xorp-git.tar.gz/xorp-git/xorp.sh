[ -d /usr/local/xorp/sbin ] && PATH=$PATH:/usr/local/xorp/sbin

export PATH
